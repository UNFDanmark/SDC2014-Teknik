#!/bin/bash

bash MassDoAsync.sh "cd /home/sdc/ && echo 'password' | sudo -H -u sdc -S $1"