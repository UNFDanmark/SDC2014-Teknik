#!/bin/bash

bash MassDo.sh "echo 'password' | sudo -S $1"