#!/bin/bash
bash Do.sh "$1" "$(cat $2)"