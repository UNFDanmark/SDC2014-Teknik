#!/bin/bash

bash MassDo.sh "cd /home/sdc/ && echo 'password' | sudo -H -u sdc -S $1"