#!/bin/bash

scp -o stricthostkeychecking=no sdcadmin@sdc1:/etc/fstab /home/sdcuser/fstab